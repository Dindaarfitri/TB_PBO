package com.reservasi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
   private static final String URL = "jdbc:postgresql://localhost:5432/reservasi_restoran";
   private static final String USER = "postgres";
   private static final String PASSWORD = "Apuak200401!";

   public DatabaseConnection() {
   }

   public static Connection connect() {
      Connection var0 = null;

      try {
            Class.forName("org.postgresql.Driver");

            var0 = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Koneksi berhasil!");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Koneksi gagal: " + e.getMessage());
        }

      return var0;
   }

   // Menambahkan main method
   public static void main(String[] args) {
      connect();  // Memanggil metode connect untuk menguji koneksi
   }
}
