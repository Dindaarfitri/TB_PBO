package com.reservasi;

import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            ReservasiInterface service = new ReservasiService();

            while (true) {
                System.out.println("\n=== Menu Reservasi Restoran ===");
                System.out.println("1. Tambah Reservasi");
                System.out.println("2. Lihat Reservasi");
                System.out.println("3. Ubah Reservasi");
                System.out.println("4. Hapus Reservasi");
                System.out.println("5. Hitung DP");
                System.out.println("6. Keluar");
                System.out.print("Pilih menu: ");

                int pilihan = scanner.nextInt();
                scanner.nextLine();

                if (pilihan == 6) {
                    System.out.println("Terima kasih!");
                    break;
                }

                switch (pilihan) {
                    case 1 -> {
                        System.out.print("Nama Pelanggan: ");
                        String nama = scanner.nextLine();
                        System.out.print("Nomor Meja: ");
                        int meja = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Tanggal (YYYY-MM-DD): ");
                        String tanggal = scanner.nextLine();
                        System.out.print("Waktu (HH:MM:SS): ");
                        String waktu = scanner.nextLine();
                        System.out.print("No HP: ");
                        String no_hp = scanner.nextLine();
                        System.out.print("Jumlah Orang: ");
                        int jumlahOrang = scanner.nextInt();
                        scanner.nextLine();
                        service.tambahReservasi(nama, meja, tanggal, waktu, no_hp, jumlahOrang);
                    }
                    case 2 -> service.lihatReservasi();
                    case 3 -> {
                        System.out.print("ID Reservasi: ");
                        int idUbah = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Nama Baru: ");
                        String namaBaru = scanner.nextLine();
                        System.out.print("Nomor Meja Baru: ");
                        int mejaBaru = scanner.nextInt();
                        scanner.nextLine();
                        service.ubahReservasi(idUbah, namaBaru, mejaBaru);
                    }
                    case 4 -> {
                        System.out.print("ID Reservasi: ");
                        int idHapus = scanner.nextInt();
                        scanner.nextLine();
                        service.hapusReservasi(idHapus);
                    }
                    case 5 -> {
                        System.out.print("ID Reservasi: ");
                        int id = scanner.nextInt();
                        scanner.nextLine();
                        double dp = service.hitungDP(id);
                        if (dp > 0) {
                            System.out.println("DP yang harus dibayar: Rp " + dp);
                        }
                    }
                    default -> System.out.println("Pilihan tidak valid!");
                }
            }
        } catch (Exception e) {
            System.out.println("Terjadi kesalahan: " + e.getMessage());
        }
    }
}
