package com.reservasi;

import java.sql.*;

public class ReservasiService implements ReservasiInterface {
    private final Connection conn;

    public ReservasiService() {
        conn = DatabaseConnection.connect();
    }

    @Override
    public void tambahReservasi(String nama, int meja, String tanggal, String waktu, String no_hp, int jumlahOrang) {
        String query = "INSERT INTO reservasi (nama_pelanggan, nomor_meja, tanggal_reservasi, waktu_reservasi, no_hp, jumlah_orang) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, nama);
            stmt.setInt(2, meja);
            stmt.setDate(3, Date.valueOf(tanggal));
            stmt.setTime(4, Time.valueOf(waktu));
            stmt.setString(5, no_hp);
            stmt.setInt(6, jumlahOrang);
            stmt.executeUpdate();
            System.out.println("Reservasi berhasil ditambahkan!");
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Override
    public void lihatReservasi() {
        String query = "SELECT * FROM reservasi";
        try (Statement stmt = conn.createStatement()) {
            ResultSet rs = stmt.executeQuery(query);
            int urutan = 1; // Inisialisasi urutan
            System.out.println("\n=== Daftar Reservasi ===");
            while (rs.next()) {
                System.out.println(
                    urutan + ". " + // Tampilkan urutan
                    "Id Reservasi: " + rs.getInt("id") + " - " +
                    rs.getString("nama_pelanggan") + " - Meja: " +
                    rs.getInt("nomor_meja") + " - " +
                    rs.getDate("tanggal_reservasi") + " " +
                    rs.getTime("waktu_reservasi") + " - " +
                    rs.getString("no_hp") + " - Jumlah Orang: " +
                    rs.getInt("jumlah_orang"));
                urutan++; // Tambahkan urutan
            }
            if (urutan == 1) {
                System.out.println("Tidak ada data reservasi.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Override
    public void ubahReservasi(int id, String nama, int meja) {
        String query = "UPDATE reservasi SET nama_pelanggan = ?, nomor_meja = ? WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, nama);
            stmt.setInt(2, meja);
            stmt.setInt(3, id);
            stmt.executeUpdate();
            System.out.println("Reservasi berhasil diubah!");
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Override
    public void hapusReservasi(int id) {
        String query = "DELETE FROM reservasi WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
            System.out.println("Reservasi berhasil dihapus!");
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Override
    public double hitungDP(int id) {
        String query = "SELECT jumlah_orang FROM reservasi WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                int jumlahOrang = rs.getInt("jumlah_orang");
                return jumlahOrang * 20000.0; // DP per orang Rp 20,000
            } else {
                System.out.println("Reservasi dengan ID tersebut tidak ditemukan.");
                return 0;
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return 0;
        }
    }
}
