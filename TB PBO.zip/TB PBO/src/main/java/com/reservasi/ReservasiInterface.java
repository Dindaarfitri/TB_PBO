package com.reservasi;

public interface ReservasiInterface {
    void tambahReservasi(String nama, int meja, String tanggal, String waktu, String no_hp, int jumlahOrang);
    void lihatReservasi();
    void ubahReservasi(int id, String nama, int meja);
    void hapusReservasi(int id);

    double hitungDP(int id);
}
